require('dotenv').config();
const TelegramBot = require('node-telegram-bot-api');
const { Pool } = require('pg');
const express = require('express');

const token = process.env.BOT_TOKEN;
const channelId = process.env.CHANNEL_ID;

if (!token) {
    console.error('Error: BOT_TOKEN not found in environment variables');
    process.exit(1);
}

const bot = new TelegramBot(token, { polling: true });
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const app = express();
const PORT = 5000;

app.get('/', (req, res) => {
    res.send(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>Waifu Bot Status</title>
            <style>
                body { font-family: Arial, sans-serif; max-width: 800px; margin: 50px auto; padding: 20px; }
                .status { background: #4CAF50; color: white; padding: 20px; border-radius: 10px; text-align: center; }
                .info { background: #f5f5f5; padding: 20px; margin-top: 20px; border-radius: 10px; }
                h1 { margin: 0; }
                p { margin: 10px 0; }
            </style>
        </head>
        <body>
            <div class="status">
                <h1>✅ Waifu Bot is Running!</h1>
                <p>Last checked: ${new Date().toLocaleString()}</p>
            </div>
            <div class="info">
                <h2>🤖 Bot Information</h2>
                <p><strong>Status:</strong> Online and Active</p>
                <p><strong>Platform:</strong> Telegram</p>
                <p><strong>Uptime:</strong> ${Math.floor(process.uptime())} seconds</p>
                <p><strong>Server:</strong> Replit</p>
            </div>
        </body>
        </html>
    `);

const fs = require('fs').promises;
const path = require('path');

// User data file storage directory
const USER_DATA_DIR = './users';

// Ensure user data directory exists
async function ensureUserDataDir() {
    try {
        await fs.mkdir(USER_DATA_DIR, { recursive: true });
    } catch (error) {
        console.error('Error creating user data directory:', error);
    }
}

ensureUserDataDir();

// Save user data to file
async function saveUserDataToFile(userId) {
    try {
        const user = await pool.query('SELECT * FROM users WHERE user_id = $1', [userId]);
        if (user.rows.length === 0) return;

        const harem = await pool.query('SELECT waifu_id FROM harem WHERE user_id = $1', [userId]);

        const userData = {
            user_id: userId,
            username: user.rows[0].username,
            first_name: user.rows[0].first_name,
            berries: user.rows[0].berries,
            daily_streak: user.rows[0].daily_streak,
            weekly_streak: user.rows[0].weekly_streak,
            favorite_waifu_id: user.rows[0].favorite_waifu_id,
            waifus: harem.rows.map(h => h.waifu_id),
            last_updated: new Date().toISOString()
        };

        const filePath = path.join(USER_DATA_DIR, `${userId}.json`);
        await fs.writeFile(filePath, JSON.stringify(userData, null, 2));
    } catch (error) {
        console.error('Error saving user data to file:', error);
    }
}

});

app.get('/health', (req, res) => {
    res.json({ 
        status: 'online', 
        uptime: process.uptime(),
        timestamp: new Date().toISOString()
    });
});

app.listen(PORT, '0.0.0.0', () => {
    console.log(`🌐 Web server running on port ${PORT}`);
});

bot.on('polling_error', (error) => {
    console.error('Polling error:', error);
});

process.on('unhandledRejection', (error) => {
    console.error('Unhandled rejection:', error);
});

const RARITY_NAMES = {
    1: '𝑪𝒐𝒎𝒎𝒐𝒏 🔘',
    2: '𝑹𝒂𝒓𝒆 🧩',
    3: '𝑬𝒑𝒊𝒄 🟣',
    4: '𝑳𝒆𝒈𝒆𝒏𝒅𝒂𝒓𝒚 🟡',
    5: '𝑺𝒖𝒎𝒎𝒆𝒓 🏖️',
    6: '𝑾𝒊𝒏𝒕𝒆𝒓 ☃️',
    7: '𝑽𝒂𝒍𝒆𝒏𝒕𝒊𝒏𝒆 💘',
    8: '𝑴𝒂𝒏𝒈𝒂 ✨',
    9: '𝑹𝒐𝒚𝒂𝒍 🏰',
    10: '𝑵𝒆𝒐𝒏 🔮',
    11: '𝑪𝒆𝒍𝒆𝒔𝒕𝒊𝒂𝒍 🌌',
    12: '𝑴𝒚𝒕𝒉𝒊𝒄𝒂𝒍 🐉',
    13: '𝑺𝒑𝒆𝒄𝒊𝒂𝒍 🫧',
    14: '𝑴𝒂𝒔𝒕𝒆𝒓𝒑𝒊𝒆𝒄𝒆 🖼️',
    15: '𝑨𝑴𝑽 🎬'
};

const RARITY_COSTS = { 14: 50000, 15: 100000 };

const userCommandCount = new Map();
const SPAM_THRESHOLD = 10;
const SPAM_WINDOW = 10000;
const SPAM_BLOCK_DURATION = 20 * 60 * 1000;

// Group bidding system
const groupBids = new Map();

async function checkMonthlyReset() {
    const now = new Date();
    if (now.getDate() === 1) {
        const lastReset = await pool.query('SELECT value FROM bot_settings WHERE key = $1', ['last_monthly_reset']);
        const lastResetMonth = lastReset.rows.length > 0 ? new Date(lastReset.rows[0].value).getMonth() : -1;

        if (lastResetMonth !== now.getMonth()) {
            await pool.query('UPDATE users SET daily_streak = 0, weekly_streak = 0');
            await pool.query(
                'INSERT INTO bot_settings (key, value) VALUES ($1, $2) ON CONFLICT (key) DO UPDATE SET value = $2',
                ['last_monthly_reset', now.toISOString()]
            );
            console.log('✅ Monthly streak reset completed');
        }
    }
}

setInterval(checkMonthlyReset, 60 * 60 * 1000);
checkMonthlyReset();

async function ensureUser(userId, username, firstName) {
    const result = await pool.query(
        'INSERT INTO users (user_id, username, first_name) VALUES ($1, $2, $3) ON CONFLICT (user_id) DO UPDATE SET username = $2, first_name = $3 RETURNING *',
        [userId, username, firstName]
    );
    await saveUserDataToFile(userId);
    return result.rows[0];
}

async function checkBanned(userId) {
    const result = await pool.query('SELECT * FROM banned_users WHERE user_id = $1', [userId]);
    return result.rows.length > 0;
}

async function checkSpamBlock(userId) {
    const result = await pool.query('SELECT * FROM spam_blocks WHERE user_id = $1 AND blocked_until > NOW()', [userId]);
    if (result.rows.length > 0) {
        return result.rows[0].blocked_until;
    }

    await pool.query('DELETE FROM spam_blocks WHERE user_id = $1 AND blocked_until <= NOW()', [userId]);
    return null;
}

async function trackSpam(userId) {
    const now = Date.now();
    const userData = userCommandCount.get(userId) || { count: 0, resetTime: now };

    if (now - userData.resetTime > SPAM_WINDOW) {
        userData.count = 1;
        userData.resetTime = now;
    } else {
        userData.count++;
    }

    userCommandCount.set(userId, userData);

    if (userData.count > SPAM_THRESHOLD) {
        const blockUntil = new Date(now + SPAM_BLOCK_DURATION);
        await pool.query(
            'INSERT INTO spam_blocks (user_id, blocked_until, spam_count) VALUES ($1, $2, 1) ON CONFLICT (user_id) DO UPDATE SET blocked_until = $2, spam_count = spam_blocks.spam_count + 1',
            [userId, blockUntil]
        );
        userCommandCount.delete(userId);
        return blockUntil;
    }

    return null;
}

async function hasRole(userId, role) {
    const result = await pool.query('SELECT * FROM roles WHERE user_id = $1 AND role_type = $2', [userId, role]);
    return result.rows.length > 0;
}

async function checkCooldown(userId, command, cooldownSeconds) {
    const result = await pool.query('SELECT last_used FROM cooldowns WHERE user_id = $1 AND command = $2', [userId, command]);
    if (result.rows.length > 0) {
        const lastUsed = new Date(result.rows[0].last_used);
        const now = new Date();
        const diff = (now - lastUsed) / 1000;
        if (diff < cooldownSeconds) {
            return Math.ceil(cooldownSeconds - diff);
        }
    }
    await pool.query(
        'INSERT INTO cooldowns (user_id, command, last_used) VALUES ($1, $2, NOW()) ON CONFLICT (user_id, command) DO UPDATE SET last_used = NOW()',
        [userId, command]
    );
    return 0;
}

async function getRandomWaifu(rarityRange = [1, 13]) {
    const result = await pool.query(
        'SELECT * FROM waifus WHERE rarity BETWEEN $1 AND $2 AND is_locked = FALSE ORDER BY RANDOM() LIMIT 1',
        rarityRange
    );
    return result.rows[0];
}

async function sendReply(chatId, messageId, text, options = {}) {
    return bot.sendMessage(chatId, text, {
        reply_to_message_id: messageId,
        parse_mode: 'HTML',
        ...options
    });
}

async function sendPhotoReply(chatId, messageId, photo, caption, options = {}) {
    return bot.sendPhoto(chatId, photo, {
        reply_to_message_id: messageId,
        caption,
        parse_mode: 'HTML',
        ...options
    });
}

async function checkUserAccess(msg) {
    if (!msg.from || msg.from.is_bot) return false;

    const userId = msg.from.id;

    if (await checkBanned(userId)) {
        await sendReply(msg.chat.id, msg.message_id, '🚫 You are banned from using this bot.');
        return false;
    }

    const spamBlock = await checkSpamBlock(userId);
    if (spamBlock) {
        const minutes = Math.ceil((new Date(spamBlock) - new Date()) / 60000);
        await sendReply(msg.chat.id, msg.message_id, `⏱️ You're blocked for spamming. Wait ${minutes} more minutes.`);
        return false;
    }

    const spamTriggered = await trackSpam(userId);
    if (spamTriggered) {
        await sendReply(msg.chat.id, msg.message_id, '🚫 Spam detected! You are blocked for 20 minutes.');
        return false;
    }

    return true;
}

bot.onText(/\/start/, async (msg) => {
    if (!await checkUserAccess(msg)) return;

    const userId = msg.from.id;
    await ensureUser(userId, msg.from.username, msg.from.first_name);

    const mainMenuKeyboard = {
        inline_keyboard: [
            [{ text: 'ADD ME BABY 💖', url: `https://t.me/${bot.options.username}?startgroup=true` }],
            [{ text: 'CREDITS', callback_data: 'menu_credits' }],
            [{ text: 'HELP', callback_data: 'menu_help' }],
            [{ text: 'UPDATES', url: 'https://t.me/+_oaZBApwiFsyNzU1' }]
        ]
    };

    const welcomeText = `👋 ʜɪ, ᴍʏ ɴᴀᴍᴇ ɪs 𝗔𝗾𝘂𝗮 𝗪𝗮𝗶𝗳𝘂 𝗯𝗼𝘁, ᴀɴ ᴀɴɪᴍᴇ-ʙᴀsᴇᴅ ɢᴀᴍᴇs ʙᴏᴛ! ᴀᴅᴅ ᴍᴇ ᴛᴏ ʏᴏᴜʀ ɢʀᴏᴜᴘ ᴀɴᴅ ᴛʜᴇ ᴇxᴘᴇʀɪᴇɴᴄᴇ ɢᴇᴛs ᴇxᴘᴀɴᴅᴇᴅ. ʟᴇᴛ's ɪɴɪᴛɪᴀᴛᴇ ᴏᴜʀ ᴊᴏᴜʀɴᴇʏ ᴛᴏɢᴇᴛʜᴇʀ!`;

    try {
        await bot.sendAnimation(msg.chat.id, 'https://www.kapwing.com/videos/691767e22b998271d946fb99', {
            caption: welcomeText,
            reply_to_message_id: msg.message_id,
            reply_markup: mainMenuKeyboard,
            parse_mode: 'HTML'
        });
    } catch (error) {
        // Fallback if GIF fails
        await sendReply(msg.chat.id, msg.message_id, welcomeText, { reply_markup: mainMenuKeyboard });
    }
});

bot.onText(/\/explore/, async (msg) => {
    if (!await checkUserAccess(msg)) return;

    const userId = msg.from.id;
    await ensureUser(userId, msg.from.username, msg.from.first_name);

    const cooldown = await checkCooldown(userId, 'explore', 60);
    if (cooldown > 0) {
        return sendReply(msg.chat.id, msg.message_id, `⏱️ Wait ${cooldown}s before exploring again!`);
    }

    const cash = Math.floor(Math.random() * 50) + 10;
    await pool.query('UPDATE users SET berries = berries + $1 WHERE user_id = $2', [cash, userId]);
    await saveUserDataToFile(userId);
    sendReply(msg.chat.id, msg.message_id, `💸 You found <b>${cash} ᴄᴀꜱʜ</b>!`);
});

bot.onText(/\/bal/, async (msg) => {
    const userId = msg.from.id;
    const user = await ensureUser(userId, msg.from.username, msg.from.first_name);
    sendReply(msg.chat.id, msg.message_id, `💰 You have <b>${user.berries} 💸 ᴄᴀꜱʜ</b>`);
});

bot.onText(/\/bonus/, async (msg) => {
    const userId = msg.from.id;
    const user = await ensureUser(userId, msg.from.username, msg.from.first_name);

    const now = new Date();
    const lastDaily = user.last_daily_claim ? new Date(user.last_daily_claim) : null;
    const lastWeekly = user.last_weekly_claim ? new Date(user.last_weekly_claim) : null;

    let message = '🎁 <b>Bonus Claims:</b>\n\n';
    let totalCash = 0;

    if (!lastDaily || (now - lastDaily) / (1000 * 60 * 60 * 24) >= 1) {
        const streak = (!lastDaily || (now - lastDaily) / (1000 * 60 * 60 * 48) < 1) ? user.daily_streak + 1 : 1;
        const dailyReward = 100 * streak;
        totalCash += dailyReward;
        await pool.query('UPDATE users SET berries = berries + $1, daily_streak = $2, last_daily_claim = NOW() WHERE user_id = $3', 
            [dailyReward, streak, userId]);
        message += `📅 Daily: +${dailyReward} 💸 ᴄᴀꜱʜ (Streak: ${streak})\n`;
    } else {
        message += `📅 Daily: Already claimed today\n`;
    }

    if (!lastWeekly || (now - lastWeekly) / (1000 * 60 * 60 * 24 * 7) >= 1) {
        const streak = (!lastWeekly || (now - lastWeekly) / (1000 * 60 * 60 * 24 * 14) < 1) ? user.weekly_streak + 1 : 1;
        const weeklyReward = 500 * streak;
        totalCash += weeklyReward;
        await pool.query('UPDATE users SET berries = berries + $1, weekly_streak = $2, last_weekly_claim = NOW() WHERE user_id = $3', 
            [weeklyReward, streak, userId]);
        message += `📆 Weekly: +${weeklyReward} 💸 ᴄᴀꜱʜ (Streak: ${streak})\n`;
    } else {
        message += `📆 Weekly: Already claimed this week\n`;
    }

    if (totalCash > 0) {
        message += `\n✨ Total: +${totalCash} 💸 ᴄᴀꜱʜ!`;
    }

    message += `\n\n⚠️ <i>Streaks reset on 1st of each month</i>`;

    sendReply(msg.chat.id, msg.message_id, message);
});

bot.onText(/\/marry(?:\s+me)?/, async (msg) => {
    if (!await checkUserAccess(msg)) return;

    const userId = msg.from.id;
    await ensureUser(userId, msg.from.username, msg.from.first_name);

    const cooldown = await checkCooldown(userId, 'marry', 3600); // 1 hour = 3600 seconds
    if (cooldown > 0) {
        const minutes = Math.floor(cooldown / 60);
        const seconds = cooldown % 60;
        return sendReply(msg.chat.id, msg.message_id, `⏱️ Wait ${minutes}m ${seconds}s before marrying again!`);
    }

    const waifu = await getRandomWaifu([1, 15]);
    if (!waifu) {
        return sendReply(msg.chat.id, msg.message_id, '❌ No waifus available yet!');
    }

    await pool.query('INSERT INTO harem (user_id, waifu_id) VALUES ($1, $2) ON CONFLICT DO NOTHING', [userId, waifu.waifu_id]);
    await saveUserDataToFile(userId);

    const gender = waifu.gender || 'Unknown';
    const message = `💍 <b>Name - ${waifu.name}</b>\n🎬 Anime - ${waifu.anime}\n✨ Rarity - ${RARITY_NAMES[waifu.rarity]}\n⚧️ Gender - ${gender}\n🆔 ID: ${waifu.waifu_id}`;

    if (waifu.image_file_id) {
        sendPhotoReply(msg.chat.id, msg.message_id, waifu.image_file_id, message);
    } else {
        sendReply(msg.chat.id, msg.message_id, message + '\n\n⚠️ <i>Image not available</i>');
    }
});

bot.onText(/\/chtime/, async (msg) => {
    if (!await checkUserAccess(msg)) return;

    const userId = msg.from.id;
    await ensureUser(userId, msg.from.username, msg.from.first_name);

    const cooldowns = await pool.query('SELECT command, last_used FROM cooldowns WHERE user_id = $1', [userId]);

    let message = '⏰ <b>Your Cooldown Status:</b>\n\n';

    const now = new Date();
    const cooldownTimes = {
        'explore': 60,
        'marry': 3600,
        'propose': 3600
    };

    if (cooldowns.rows.length === 0) {
        message += '✅ All commands are ready to use!';
    } else {
        for (const cd of cooldowns.rows) {
            const lastUsed = new Date(cd.last_used);
            const requiredCooldown = cooldownTimes[cd.command] || 0;
            const elapsed = Math.floor((now - lastUsed) / 1000);
            const remaining = Math.max(0, requiredCooldown - elapsed);

            if (remaining > 0) {
                const minutes = Math.floor(remaining / 60);
                const seconds = remaining % 60;
                message += `⏱️ /${cd.command}: ${minutes}m ${seconds}s remaining\n`;
            } else {
                message += `✅ /${cd.command}: Ready!\n`;
            }
        }
    }

    sendReply(msg.chat.id, msg.message_id, message);
});

bot.onText(/\/changetime/, async (msg) => {
    if (!await checkUserAccess(msg)) return;

    const userId = msg.from.id;

    if (!await hasRole(userId, 'sudo') && !await hasRole(userId, 'dev')) {
        return sendReply(msg.chat.id, msg.message_id, '❌ Admin permission required!');
    }

    if (!msg.reply_to_message) {
        return sendReply(msg.chat.id, msg.message_id, '❌ Reply to a user to reset their cooldowns!');
    }

    const targetId = msg.reply_to_message.from.id;

    await pool.query('DELETE FROM cooldowns WHERE user_id = $1', [targetId]);

    sendReply(msg.chat.id, msg.message_id, `✅ All cooldowns reset for user ${msg.reply_to_message.from.first_name}!`);
});

bot.onText(/\/dwaifu/, async (msg) => {
    const userId = msg.from.id;
    await ensureUser(userId, msg.from.username, msg.from.first_name);

    const result = await pool.query('SELECT last_claim_date FROM daily_waifu_claims WHERE user_id = $1', [userId]);
    const today = new Date().toISOString().split('T')[0];

    if (result.rows.length > 0 && result.rows[0].last_claim_date === today) {
        return sendReply(msg.chat.id, msg.message_id, '⏰ You already claimed your daily waifu today!');
    }

    const waifu = await getRandomWaifu([1, 13]);
    if (!waifu) {
        return sendReply(msg.chat.id, msg.message_id, '❌ No waifus available!');
    }

    await pool.query('INSERT INTO harem (user_id, waifu_id) VALUES ($1, $2) ON CONFLICT DO NOTHING', [userId, waifu.waifu_id]);
    await pool.query('INSERT INTO daily_waifu_claims (user_id, last_claim_date) VALUES ($1, $2) ON CONFLICT (user_id) DO UPDATE SET last_claim_date = $2',
        [userId, today]);

    const message = `🎁 <b>Daily Waifu: ${waifu.name}!</b>\n🎬 ${waifu.anime}\n${RARITY_NAMES[waifu.rarity]}\n🆔 ID: ${waifu.waifu_id}`;

    if (waifu.image_file_id) {
        sendPhotoReply(msg.chat.id, msg.message_id, waifu.image_file_id, message);
    } else {
        sendReply(msg.chat.id, msg.message_id, message);
    }
});

bot.onText(/\/propose/, async (msg) => {
    const userId = msg.from.id;
    const user = await ensureUser(userId, msg.from.username, msg.from.first_name);

    const rarity = Math.random() < 0.5 ? 14 : 15;
    const cost = RARITY_COSTS[rarity];

    if (user.berries < cost) {
        return sendReply(msg.chat.id, msg.message_id, `❌ Need <b>${cost} 💸 ᴄᴀꜱʜ</b> to propose for ${RARITY_NAMES[rarity]} waifu!`);
    }

    const success = Math.random() < 0.3;

    await pool.query('UPDATE users SET berries = berries - $1 WHERE user_id = $2', [cost, userId]);

    if (!success) {
        return sendReply(msg.chat.id, msg.message_id, `💔 Proposal failed! Lost ${cost} 💸 ᴄᴀꜱʜ.`);
    }

    const waifu = await getRandomWaifu([rarity, rarity]);
    if (!waifu) {
        return sendReply(msg.chat.id, msg.message_id, `💔 No ${RARITY_NAMES[rarity]} waifus available!`);
    }

    await pool.query('INSERT INTO harem (user_id, waifu_id) VALUES ($1, $2) ON CONFLICT DO NOTHING', [userId, waifu.waifu_id]);

    const message = `💖 <b>Proposal Success! You got ${waifu.name}!</b>\n🎬 ${waifu.anime}\n${RARITY_NAMES[waifu.rarity]}\n🆔 ID: ${waifu.waifu_id}`;

    if (waifu.image_file_id) {
        sendPhotoReply(msg.chat.id, msg.message_id, waifu.image_file_id, message);
    } else {
        sendReply(msg.chat.id, msg.message_id, message);
    }
});

bot.onText(/\/harem(?:\s+(\d+))?/, async (msg, match) => {
    const userId = msg.from.id;
    const user = await ensureUser(userId, msg.from.username, msg.from.first_name);

    const page = parseInt(match[1]) || 1;
    const limit = 10;
    const offset = (page - 1) * limit;

    const result = await pool.query(
        `SELECT w.*, h.acquired_date FROM harem h 
         JOIN waifus w ON h.waifu_id = w.waifu_id 
         WHERE h.user_id = $1 
         ORDER BY h.acquired_date DESC 
         LIMIT $2 OFFSET $3`,
        [userId, limit, offset]
    );

    const countResult = await pool.query('SELECT COUNT(*) FROM harem WHERE user_id = $1', [userId]);
    const total = parseInt(countResult.rows[0].count);

    if (total === 0) {
        return sendReply(msg.chat.id, msg.message_id, '📭 Your harem is empty! Use /marry to get waifus.');
    }

    const userResult = await pool.query('SELECT favorite_waifu_id FROM users WHERE user_id = $1', [userId]);
    const favId = userResult.rows[0].favorite_waifu_id;

    const username = user.username ? `@${user.username}` : user.first_name;
    let message = `📚 <b>${username}'s Harem (Page ${page}/${Math.ceil(total / limit)}):</b>\n\n`;

    result.rows.forEach((w, i) => {
        const fav = w.waifu_id === favId ? '⭐' : '';
        message += `${offset + i + 1}. ${fav} ${w.name} - ${w.anime} [${RARITY_NAMES[w.rarity]}] (ID: ${w.waifu_id})\n`;
    });

    message += `\nTotal: ${total} waifus`;

    if (favId) {
        const favResult = await pool.query('SELECT * FROM waifus WHERE waifu_id = $1', [favId]);
        if (favResult.rows.length > 0 && favResult.rows[0].image_file_id) {
            return sendPhotoReply(msg.chat.id, msg.message_id, favResult.rows[0].image_file_id, message);
        }
    }

    sendReply(msg.chat.id, msg.message_id, message);
});

bot.onText(/\/info/, async (msg) => {
    if (!await checkUserAccess(msg)) return;

    const userId = msg.from.id;
    const user = await ensureUser(userId, msg.from.username, msg.from.first_name);

    const joinDate = new Date(user.created_at);
    const now = new Date();
    const daysSinceJoin = Math.floor((now - joinDate) / (1000 * 60 * 60 * 24));

    const displayName = user.first_name;
    const username = user.username ? `@${user.username}` : 'No username';
    const userLink = `tg://user?id=${userId}`;

    const message = `
👤 <b>User Information</b>

🆔 <b>Telegram ID:</b> <code>${userId}</code>
👤 <b>Name:</b> ${displayName}
🔗 <b>Username:</b> ${username}
📅 <b>Joined:</b> ${daysSinceJoin} days ago
🔗 <b>Profile:</b> <a href="${userLink}">Click here</a>
💰 <b>Cash:</b> ${user.berries} 💸 ᴄᴀꜱʜ
    `;

    sendReply(msg.chat.id, msg.message_id, message);
});

bot.onText(/\/fav (\d+)/, async (msg, match) => {
    const userId = msg.from.id;
    const waifuId = parseInt(match[1]);

    const owned = await pool.query('SELECT * FROM harem WHERE user_id = $1 AND waifu_id = $2', [userId, waifuId]);
    if (owned.rows.length === 0) {
        return sendReply(msg.chat.id, msg.message_id, '❌ You don\'t own this waifu!');
    }

    await pool.query('UPDATE users SET favorite_waifu_id = $1 WHERE user_id = $2', [waifuId, userId]);
    sendReply(msg.chat.id, msg.message_id, '⭐ Favorite waifu updated!');
});

bot.onText(/\/d (\d+)/, async (msg, match) => {
    const waifuId = parseInt(match[1]);

    const result = await pool.query('SELECT * FROM waifus WHERE waifu_id = $1', [waifuId]);
    if (result.rows.length === 0) {
        return sendReply(msg.chat.id, msg.message_id, '❌ Waifu not found!');
    }

    const waifu = result.rows[0];
    const message = `
📝 <b>Waifu Details:</b>
👤 Name: ${waifu.name}
🎬 Anime: ${waifu.anime}
✨ Rarity: ${RARITY_NAMES[waifu.rarity]}
🆔 ID: ${waifu.waifu_id}
    `;

    if (waifu.image_file_id) {
        sendPhotoReply(msg.chat.id, msg.message_id, waifu.image_file_id, message);
    } else {
        sendReply(msg.chat.id, msg.message_id, message);
    }
});

bot.onText(/\/dprofile/, async (msg) => {
    const userId = msg.from.id;
    const user = await ensureUser(userId, msg.from.username, msg.from.first_name);

    const haremCount = await pool.query('SELECT COUNT(*) FROM harem WHERE user_id = $1', [userId]);

    let message = `
👤 <b>Profile: ${user.first_name}</b>
💰 Cash: ${user.berries} 💸 ᴄᴀꜱʜ
📚 Waifus: ${haremCount.rows[0].count}
🔥 Daily Streak: ${user.daily_streak}
📅 Weekly Streak: ${user.weekly_streak}
    `;

    try {
        const userPhotos = await bot.getUserProfilePhotos(userId, { limit: 1 });
        if (userPhotos.total_count > 0) {
            const photoId = userPhotos.photos[0][0].file_id;

            if (user.favorite_waifu_id) {
                const favResult = await pool.query('SELECT * FROM waifus WHERE waifu_id = $1', [user.favorite_waifu_id]);
                if (favResult.rows.length > 0) {
                    const fav = favResult.rows[0];
                    message += `⭐ Favorite: ${fav.name}`;
                }
            }

            return sendPhotoReply(msg.chat.id, msg.message_id, photoId, message);
        }
    } catch (error) {
        console.error('Error fetching profile photo:', error);
    }

    if (user.favorite_waifu_id) {
        const favResult = await pool.query('SELECT * FROM waifus WHERE waifu_id = $1', [user.favorite_waifu_id]);
        if (favResult.rows.length > 0) {
            const fav = favResult.rows[0];
            message += `⭐ Favorite: ${fav.name}`;
            if (fav.image_file_id) {
                return sendPhotoReply(msg.chat.id, msg.message_id, fav.image_file_id, message);
            }
        }
    }

    sendReply(msg.chat.id, msg.message_id, message);
});

bot.onText(/\/pay (\d+)/, async (msg, match) => {
    if (!msg.reply_to_message) {
        return sendReply(msg.chat.id, msg.message_id, '❌ Reply to a user to send them 💸 ᴄᴀꜱʜ!');
    }

    const userId = msg.from.id;
    const targetId = msg.reply_to_message.from.id;
    const amount = parseInt(match[1]);

    if (userId === targetId) {
        return sendReply(msg.chat.id, msg.message_id, '❌ You cannot send 💸 ᴄᴀꜱʜ to yourself!');
    }

    if (amount <= 0) {
        return sendReply(msg.chat.id, msg.message_id, '❌ Amount must be positive!');
    }

    const user = await ensureUser(userId, msg.from.username, msg.from.first_name);

    if (user.berries < amount) {
        return sendReply(msg.chat.id, msg.message_id, `❌ You only have ${user.berries} 💸 ᴄᴀꜱʜ!`);
    }

    await ensureUser(targetId, msg.reply_to_message.from.username, msg.reply_to_message.from.first_name);

    await pool.query('UPDATE users SET berries = berries - $1 WHERE user_id = $2', [amount, userId]);
    await pool.query('UPDATE users SET berries = berries + $1 WHERE user_id = $2', [amount, targetId]);

    sendReply(msg.chat.id, msg.message_id, `✅ Sent <b>${amount} 💸 ᴄᴀꜱʜ</b> to ${msg.reply_to_message.from.first_name}!`);
});

bot.onText(/\/gift(?:\s+(\d+))?/, async (msg, match) => {
    if (!msg.reply_to_message) {
        return sendReply(msg.chat.id, msg.message_id, '❌ Reply to a user and provide waifu ID or cash amount!\nUsage: /gift <waifu_id or cash_amount>');
    }

    const userId = msg.from.id;
    const targetId = msg.reply_to_message.from.id;

    if (userId === targetId) {
        return sendReply(msg.chat.id, msg.message_id, '❌ You cannot gift to yourself!');
    }

    if (!match[1]) {
        return sendReply(msg.chat.id, msg.message_id, '❌ Please specify waifu ID or cash amount!\nUsage: /gift <waifu_id or cash_amount>');
    }

    const value = parseInt(match[1]);
    const user = await ensureUser(userId, msg.from.username, msg.from.first_name);
    await ensureUser(targetId, msg.reply_to_message.from.username, msg.reply_to_message.from.first_name);

    // Check if it's a waifu gift
    const waifuCheck = await pool.query('SELECT * FROM harem WHERE user_id = $1 AND waifu_id = $2', [userId, value]);

    if (waifuCheck.rows.length > 0) {
        // Gift waifu
        await pool.query('DELETE FROM harem WHERE user_id = $1 AND waifu_id = $2', [userId, value]);
        await pool.query('INSERT INTO harem (user_id, waifu_id) VALUES ($1, $2) ON CONFLICT DO NOTHING', [targetId, value]);

        const waifuDetails = await pool.query('SELECT * FROM waifus WHERE waifu_id = $1', [value]);
        const waifu = waifuDetails.rows[0];

        return sendReply(msg.chat.id, msg.message_id, `✅ Gifted <b>${waifu.name}</b> to ${msg.reply_to_message.from.first_name}!`);
    } else {
        // Gift cash
        if (user.berries < value) {
            return sendReply(msg.chat.id, msg.message_id, `❌ You only have ${user.berries} 💸 ᴄᴀꜱʜ!`);
        }

        await pool.query('UPDATE users SET berries = berries - $1 WHERE user_id = $2', [value, userId]);
        await pool.query('UPDATE users SET berries = berries + $1 WHERE user_id = $2', [value, targetId]);

        return sendReply(msg.chat.id, msg.message_id, `✅ Gifted <b>${value} 💸 ᴄᴀꜱʜ</b> to ${msg.reply_to_message.from.first_name}!`);
    }
});

bot.onText(/\/goal (\d+)/, async (msg, match) => {
    const userId = msg.from.id;
    const amount = parseInt(match[1]);
    const user = await ensureUser(userId, msg.from.username, msg.from.first_name);

    if (amount <= 0 || user.berries < amount) {
        return sendReply(msg.chat.id, msg.message_id, '❌ Invalid amount or insufficient 💸 ᴄᴀꜱʜ!');
    }

    const win = Math.random() < 0.4;

    if (win) {
        await pool.query('UPDATE users SET berries = berries + $1 WHERE user_id = $2', [amount, userId]);
        sendReply(msg.chat.id, msg.message_id, `🎯 You won! +<b>${amount} 💸 ᴄᴀꜱʜ</b>!`);
    } else {
        await pool.query('UPDATE users SET berries = berries - $1 WHERE user_id = $2', [amount, userId]);
        sendReply(msg.chat.id, msg.message_id, `💔 You lost <b>${amount} 💸 ᴄᴀꜱʜ</b>!`);
    }
});

bot.onText(/\/dart (\d+)/, async (msg, match) => {
    const userId = msg.from.id;
    const amount = parseInt(match[1]);
    const user = await ensureUser(userId, msg.from.username, msg.from.first_name);

    if (amount <= 0 || user.berries < amount) {
        return sendReply(msg.chat.id, msg.message_id, '❌ Invalid amount or insufficient 💸 ᴄᴀꜱʜ!');
    }

    const win = Math.random() < 0.3;

    if (win) {
        await pool.query('UPDATE users SET berries = berries + $1 WHERE user_id = $2', [amount * 2, userId]);
        sendReply(msg.chat.id, msg.message_id, `🎯 You won! +<b>${amount * 2} 💸 ᴄᴀꜱʜ</b>!`);
    } else {
        await pool.query('UPDATE users SET berries = berries - $1 WHERE user_id = $2', [amount, userId]);
        sendReply(msg.chat.id, msg.message_id, `💔 You lost <b>${amount} 💸 ᴄᴀꜱʜ</b>!`);
    }
});

bot.onText(/\/top/, async (msg) => {
    const cashTop = await pool.query('SELECT user_id, username, first_name, berries FROM users ORDER BY berries DESC LIMIT 10');

    let message = '💸 <b>TOP 💸 ᴄᴀꜱʜ HOLDERS</b>\n\n';
    cashTop.rows.forEach((u, i) => {
        const name = u.username ? `@${u.username}` : u.first_name;
        message += `${i + 1}. ${name} - ${u.berries} 💸 ᴄᴀꜱʜ\n`;
    });

    const topKeyboard = {
        inline_keyboard: [
            [
                { text: '💸 ᴄᴀꜱʜ', callback_data: 'top_cash' },
                { text: '🩷 ᴡᴀɪғᴜs', callback_data: 'top_waifus' }
            ]
        ]
    };

    sendReply(msg.chat.id, msg.message_id, message, { reply_markup: topKeyboard });
});

bot.onText(/\/store/, async (msg) => {
    const userId = msg.from.id;
    await ensureUser(userId, msg.from.username, msg.from.first_name);

    const today = new Date().toISOString().split('T')[0];

    let storeItems = await pool.query(
        'SELECT ds.*, w.* FROM daily_store ds JOIN waifus w ON ds.waifu_id = w.waifu_id WHERE ds.store_date = $1 AND ds.purchased_by IS NULL',
        [today]
    );

    if (storeItems.rows.length === 0) {
        const waifus = await pool.query('SELECT * FROM waifus WHERE is_locked = FALSE ORDER BY RANDOM() LIMIT 5');

        for (const waifu of waifus.rows) {
            const price = waifu.rarity * 1000 + Math.floor(Math.random() * 500);
            await pool.query(
                'INSERT INTO daily_store (waifu_id, price, store_date) VALUES ($1, $2, $3)',
                [waifu.waifu_id, price, today]
            );
        }

        storeItems = await pool.query(
            'SELECT ds.*, w.* FROM daily_store ds JOIN waifus w ON ds.waifu_id = w.waifu_id WHERE ds.store_date = $1 AND ds.purchased_by IS NULL',
            [today]
        );
    }

    if (storeItems.rows.length === 0) {
        return sendReply(msg.chat.id, msg.message_id, '🏪 Store is empty today! Check back tomorrow.');
    }

    let message = '🏪 <b>Daily Waifu Store</b>\n\n';
    storeItems.rows.forEach((item, i) => {
        message += `${i + 1}. ${item.name} (${item.anime})\n   ${RARITY_NAMES[item.rarity]} - ${item.price} 💸 ᴄᴀꜱʜ\n   ID: ${item.waifu_id}\n\n`;
    });
    message += 'Use /buy &lt;waifu_id&gt; to purchase!';

    sendReply(msg.chat.id, msg.message_id, message);
});

bot.onText(/\/buy (\d+)/, async (msg, match) => {
    const userId = msg.from.id;
    const waifuId = parseInt(match[1]);
    const user = await ensureUser(userId, msg.from.username, msg.from.first_name);
    const today = new Date().toISOString().split('T')[0];

    const storeItem = await pool.query(
        'SELECT ds.*, w.* FROM daily_store ds JOIN waifus w ON ds.waifu_id = w.waifu_id WHERE ds.waifu_id = $1 AND ds.store_date = $2 AND ds.purchased_by IS NULL',
        [waifuId, today]
    );

    if (storeItem.rows.length === 0) {
        return sendReply(msg.chat.id, msg.message_id, '❌ This waifu is not available in the store!');
    }

    const item = storeItem.rows[0];

    if (user.berries < item.price) {
        return sendReply(msg.chat.id, msg.message_id, `❌ You need ${item.price} 💸 ᴄᴀꜱʜ! You have ${user.berries}.`);
    }

    await pool.query('UPDATE users SET berries = berries - $1 WHERE user_id = $2', [item.price, userId]);
    await pool.query('INSERT INTO harem (user_id, waifu_id) VALUES ($1, $2) ON CONFLICT DO NOTHING', [userId, waifuId]);
    await pool.query('UPDATE daily_store SET purchased_by = $1, purchased_at = NOW() WHERE id = $2', [userId, item.id]);

    const message = `✅ <b>Purchased ${item.name}!</b>\n🎬 ${item.anime}\n${RARITY_NAMES[item.rarity]}\n💰 Spent ${item.price} 💸 ᴄᴀꜱʜ`;

    if (item.image_file_id) {


bot.onText(/\/tgm (.+)/, async (msg, match) => {
    const imageUrl = match[1].trim();

    // Validate URL
    if (!imageUrl.startsWith('http://') && !imageUrl.startsWith('https://')) {
        return sendReply(msg.chat.id, msg.message_id, '❌ Please provide a valid image URL!');
    }

    const message = `🖼️ <b>Your Image Link:</b>\n\n<a href="${imageUrl}">Click here to view image</a>\n\n📎 Direct URL: <code>${imageUrl}</code>`;

    sendReply(msg.chat.id, msg.message_id, message);
});

        sendPhotoReply(msg.chat.id, msg.message_id, item.image_file_id, message);
    } else {
        sendReply(msg.chat.id, msg.message_id, message);
    }
});

bot.onText(/\/dmode/, async (msg) => {
    const userId = msg.from.id;
    await ensureUser(userId, msg.from.username, msg.from.first_name);

    const keyboard = {
        inline_keyboard: [
            [
                { text: '⚪ Common', callback_data: 'filter_rarity_1-3' },
                { text: '🟢 Uncommon', callback_data: 'filter_rarity_4-6' }
            ],
            [
                { text: '🔵 Rare', callback_data: 'filter_rarity_7-9' },
                { text: '🟣 Epic', callback_data: 'filter_rarity_10-11' }
            ],
            [
                { text: '🟡 Legendary', callback_data: 'filter_rarity_12-13' },
                { text: '🔴 Manga', callback_data: 'filter_rarity_14' }
            ],
            [
                { text: '👑 Royal', callback_data: 'filter_rarity_15' },
                { text: '📚 All Waifus', callback_data: 'filter_all' }
            ]
        ]
    };

    sendReply(msg.chat.id, msg.message_id, '🔍 <b>Filter your harem by rarity:</b>', { reply_markup: keyboard });
});

bot.onText(/\/gban (\d+)/, async (msg, match) => {
    const userId = msg.from.id;

    if (!await hasRole(userId, 'dev') && !await hasRole(userId, 'sudo')) {
        return sendReply(msg.chat.id, msg.message_id, '❌ Admin permission required!');
    }

    const targetId = parseInt(match[1]);

    // Store user data before banning
    const userData = await pool.query('SELECT * FROM users WHERE user_id = $1', [targetId]);
    const haremData = await pool.query('SELECT waifu_id FROM harem WHERE user_id = $1', [targetId]);

    if (userData.rows.length > 0) {
        const user = userData.rows[0];
        const waifuIds = haremData.rows.map(r => r.waifu_id);

        await pool.query(
            'INSERT INTO banned_users (user_id, banned_by, reason, stored_berries, stored_waifus) VALUES ($1, $2, $3, $4, $5) ON CONFLICT (user_id) DO UPDATE SET banned_by = $2, reason = $3, stored_berries = $4, stored_waifus = $5, banned_at = NOW()',
            [targetId, userId, 'Banned by admin', user.berries, JSON.stringify(waifuIds)]
        );
    } else {
        await pool.query('INSERT INTO banned_users (user_id, banned_by, reason) VALUES ($1, $2, $3) ON CONFLICT DO NOTHING',
            [targetId, userId, 'Banned by admin']);
    }

    await pool.query('DELETE FROM harem WHERE user_id = $1', [targetId]);
    await pool.query('UPDATE users SET berries = 0, daily_streak = 0, weekly_streak = 0 WHERE user_id = $1', [targetId]);

    sendReply(msg.chat.id, msg.message_id, `✅ User ${targetId} has been banned. Data stored for recovery.`);
});

bot.onText(/\/gunban (\d+)/, async (msg, match) => {
    const userId = msg.from.id;

    if (!await hasRole(userId, 'dev') && !await hasRole(userId, 'sudo')) {
        return sendReply(msg.chat.id, msg.message_id, '❌ Admin permission required!');
    }

    const targetId = parseInt(match[1]);

    const bannedData = await pool.query('SELECT * FROM banned_users WHERE user_id = $1', [targetId]);

    if (bannedData.rows.length > 0) {
        const data = bannedData.rows[0];

        // Restore cash
        if (data.stored_berries) {
            await pool.query('UPDATE users SET berries = $1 WHERE user_id = $2', [data.stored_berries, targetId]);
        }

        // Restore waifus
        if (data.stored_waifus) {
            const waifuIds = JSON.parse(data.stored_waifus);
            for (const waifuId of waifuIds) {
                await pool.query('INSERT INTO harem (user_id, waifu_id) VALUES ($1, $2) ON CONFLICT DO NOTHING', [targetId, waifuId]);
            }
        }
    }

    await pool.query('DELETE FROM banned_users WHERE user_id = $1', [targetId]);

    sendReply(msg.chat.id, msg.message_id, `✅ User ${targetId} has been unbanned and all data restored!`);
});

bot.onText(/\/dredeem (.+)/, async (msg, match) => {
    const userId = msg.from.id;
    const code = match[1].trim();
    await ensureUser(userId, msg.from.username, msg.from.first_name);

    const result = await pool.query('SELECT * FROM redeem_codes WHERE code = $1', [code]);

    if (result.rows.length === 0) {
        return sendReply(msg.chat.id, msg.message_id, '❌ Invalid code!');
    }

    const redeemCode = result.rows[0];

    if (redeemCode.quantity_remaining <= 0) {
        return sendReply(msg.chat.id, msg.message_id, '❌ Code expired or fully used!');
    }

    if (redeemCode.type === 'berry') {
        await pool.query('UPDATE users SET berries = berries + $1 WHERE user_id = $2', [redeemCode.value, userId]);
        await pool.query('UPDATE redeem_codes SET quantity_remaining = quantity_remaining - 1 WHERE code = $1', [code]);

        sendReply(msg.chat.id, msg.message_id, `✅ Redeemed <b>${redeemCode.value} 💸 ᴄᴀꜱʜ</b>!`);
    } else if (redeemCode.type === 'waifu') {
        await pool.query('INSERT INTO harem (user_id, waifu_id) VALUES ($1, $2) ON CONFLICT DO NOTHING', [userId, redeemCode.value]);
        await pool.query('UPDATE redeem_codes SET quantity_remaining = quantity_remaining - 1 WHERE code = $1', [code]);

        const waifu = await pool.query('SELECT * FROM waifus WHERE waifu_id = $1', [redeemCode.value]);
        if (waifu.rows.length > 0) {
            sendReply(msg.chat.id, msg.message_id, `✅ Redeemed <b>${waifu.rows[0].name}</b>!`);
        } else {
            sendReply(msg.chat.id, msg.message_id, `✅ Waifu code redeemed!`);
        }
    }
});

bot.onText(/\/gen(?:\s+(.+))?/, async (msg, match) => {
    const userId = msg.from.id;

    if (!await hasRole(userId, 'sudo') && !await hasRole(userId, 'dev')) {
        return sendReply(msg.chat.id, msg.message_id, '❌ Admin permission required!');
    }

    if (!match[1]) {
        return sendReply(msg.chat.id, msg.message_id, '❌ Usage: /gen <cash_amount> <quantity> OR /gen waifu <waifu_id> <quantity>');
    }

    const args = match[1].split(' ');

    if (args[0].toLowerCase() === 'waifu' && args.length === 3) {
        const waifuId = parseInt(args[1]);
        const quantity = parseInt(args[2]);

        const code = 'WAIFU' + Math.random().toString(36).substring(2, 10).toUpperCase();

        await pool.query('INSERT INTO redeem_codes (code, type, value, quantity_remaining, created_by) VALUES ($1, $2, $3, $4, $5)',
            [code, 'waifu', waifuId, quantity, userId]);

        sendReply(msg.chat.id, msg.message_id, `✅ Generated waifu code!\n\n<code>${code}</code>\n\n👤 Waifu ID: ${waifuId}\n📦 Uses: ${quantity}`);
    } else if (args.length === 2) {
        const amount = parseInt(args[0]);
        const quantity = parseInt(args[1]);

        const code = 'CASH' + Math.random().toString(36).substring(2, 10).toUpperCase();

        await pool.query('INSERT INTO redeem_codes (code, type, value, quantity_remaining, created_by) VALUES ($1, $2, $3, $4, $5)',
            [code, 'berry', amount, quantity, userId]);

        sendReply(msg.chat.id, msg.message_id, `✅ Generated cash code!\n\n<code>${code}</code>\n\n💰 Amount: ${amount} 💸 ᴄᴀꜱʜ\n📦 Uses: ${quantity}`);
    } else {
        sendReply(msg.chat.id, msg.message_id, '❌ Invalid format! Use:\n/gen <cash_amount> <quantity>\nOR\n/gen waifu <waifu_id> <quantity>');
    }
});

// Group bidding system
bot.onText(/\/bid(?:\s+(\d+))?/, async (msg, match) => {
    if (msg.chat.type !== 'group' && msg.chat.type !== 'supergroup') {
        return sendReply(msg.chat.id, msg.message_id, '❌ This command only works in groups!');
    }

    if (!await checkUserAccess(msg)) return;

    const groupId = msg.chat.id;
    const userId = msg.from.id;
    const user = await ensureUser(userId, msg.from.username, msg.from.first_name);

    const bidData = groupBids.get(groupId);

    if (!bidData || !bidData.active) {
        return sendReply(msg.chat.id, msg.message_id, '❌ No active bidding event!');
    }

    if (!match[1]) {
        return sendReply(msg.chat.id, msg.message_id, `❌ Please specify your bid amount!\nCurrent highest bid: ${bidData.highestBid} 💸 ᴄᴀꜱʜ`);
    }

    const bidAmount = parseInt(match[1]);

    if (bidAmount < 5000) {
        return sendReply(msg.chat.id, msg.message_id, '❌ Minimum bid is 5,000 💸 ᴄᴀꜱʜ!');
    }

    if (bidAmount <= bidData.highestBid) {
        return sendReply(msg.chat.id, msg.message_id, `❌ Your bid must be higher than ${bidData.highestBid} 💸 ᴄᴀꜱʜ!`);
    }

    if (user.berries < bidAmount) {
        return sendReply(msg.chat.id, msg.message_id, `❌ You only have ${user.berries} 💸 ᴄᴀꜱʜ!`);
    }

    bidData.highestBid = bidAmount;
    bidData.highestBidder = userId;
    bidData.highestBidderName = msg.from.first_name;

    groupBids.set(groupId, bidData);

    sendReply(msg.chat.id, msg.message_id, `✅ <b>${msg.from.first_name}</b> bid <b>${bidAmount} 💸 ᴄᴀꜱʜ</b>!\n\n🏆 Current highest bid!`);
});

bot.onText(/\/upload/, async (msg) => {
    const userId = msg.from.id;

    if (!await hasRole(userId, 'uploader') && !await hasRole(userId, 'sudo') && !await hasRole(userId, 'dev')) {
        return sendReply(msg.chat.id, msg.message_id, '❌ You need uploader permissions!');
    }

    sendReply(msg.chat.id, msg.message_id, 'Send waifu photo with caption:\nWaifu Name : Name\nAnime Name : Anime\nRarity N\n\nOr send text only.');
});

bot.on('message', async (msg) => {
    if (!msg.text && !msg.photo) return;
    if (msg.text && msg.text.startsWith('/')) return;

    const userId = msg.from.id;
    const text = msg.caption || msg.text || '';

    if (text.includes('Waifu Name') && text.includes('Anime Name') && text.includes('Rarity')) {
        if (!await hasRole(userId, 'uploader') && !await hasRole(userId, 'sudo') && !await hasRole(userId, 'dev')) {
            return;
        }

        const nameMatch = text.match(/Waifu Name\s*:\s*(.+)/i);
        const animeMatch = text.match(/Anime Name\s*:\s*(.+)/i);
        const rarityMatch = text.match(/Rarity\s+(\d+)/i);

        if (!nameMatch || !animeMatch || !rarityMatch) {
            return sendReply(msg.chat.id, msg.message_id, '❌ Invalid format!');
        }

        const name = nameMatch[1].trim();
        const anime = animeMatch[1].trim();
        const rarity = parseInt(rarityMatch[1]);

        if (rarity < 1 || rarity > 15) {
            return sendReply(msg.chat.id, msg.message_id, '❌ Rarity must be 1-15!');
        }

        const fileId = msg.photo ? msg.photo[msg.photo.length - 1].file_id : null;

        const result = await pool.query(
            'INSERT INTO waifus (name, anime, rarity, image_file_id, uploaded_by) VALUES ($1, $2, $3, $4, $5) RETURNING *',
            [name, anime, rarity, fileId, userId]);

        const waifu = result.rows[0];

        const channelMessage = `
✨ <b>New Waifu Added!</b>
👤 ${waifu.name}
🎬 ${waifu.anime}
${RARITY_NAMES[rarity]}
🆔 ID: ${waifu.waifu_id}
📤 Uploaded by: ${msg.from.first_name}
        `;

        if (channelId && fileId) {
            bot.sendPhoto(channelId, fileId, { caption: channelMessage, parse_mode: 'HTML' }).catch(() => {});
        } else if (channelId) {
            bot.sendMessage(channelId, channelMessage, { parse_mode: 'HTML' }).catch(() => {});
        }

        sendReply(msg.chat.id, msg.message_id, `✅ Waifu uploaded! ID: ${waifu.waifu_id}`);
    }

    if (msg.chat.type === 'group' || msg.chat.type === 'supergroup') {
        const groupId = msg.chat.id;

        const settings = await pool.query('SELECT spawn_rate FROM group_settings WHERE group_id = $1', [groupId]);
        const spawnRate = settings.rows.length > 0 ? settings.rows[0].spawn_rate : 200;

        await pool.query(
            'INSERT INTO spawn_tracker (group_id, message_count) VALUES ($1, 1) ON CONFLICT (group_id) DO UPDATE SET message_count = spawn_tracker.message_count + 1',
            [groupId]
        );

        const tracker = await pool.query('SELECT message_count, active_spawn_waifu_id FROM spawn_tracker WHERE group_id = $1', [groupId]);

        if (tracker.rows[0].message_count >= spawnRate && !tracker.rows[0].active_spawn_waifu_id) {
            const waifu = await getRandomWaifu([1, 15]);
            if (waifu) {
                await pool.query('UPDATE spawn_tracker SET active_spawn_waifu_id = $1, message_count = 0 WHERE group_id = $2', 
                    [waifu.waifu_id, groupId]);

                // Start bidding event
                groupBids.set(groupId, {
                    active: true,
                    waifuId: waifu.waifu_id,
                    highestBid: 5000,
                    highestBidder: null,
                    highestBidderName: null,
                    startTime: Date.now()
                });

                const spawnMsg = `🌟 <b>Group Bidding Event!</b>\n\n👤 Character: ${waifu.name}\n🎬 Anime: ${waifu.anime}\n${RARITY_NAMES[waifu.rarity]}\n\n💰 Starting price: 5,000 💸 ᴄᴀꜱʜ\n⏰ You have 60 seconds to bid!\n\nUse /bid &lt;amount&gt; to compete!`;

                if (waifu.image_file_id) {
                    bot.sendPhoto(groupId, waifu.image_file_id, { caption: spawnMsg, parse_mode: 'HTML' });
                } else {
                    bot.sendMessage(groupId, spawnMsg, { parse_mode: 'HTML' });
                }

                // End bidding after 60 seconds
                setTimeout(async () => {
                    const bidData = groupBids.get(groupId);

                    if (bidData && bidData.active) {
                        bidData.active = false;
                        groupBids.set(groupId, bidData);

                        if (bidData.highestBidder) {
                            const winner = await pool.query('SELECT * FROM users WHERE user_id = $1', [bidData.highestBidder]);

                            if (winner.rows.length > 0 && winner.rows[0].berries >= bidData.highestBid) {
                                await pool.query('UPDATE users SET berries = berries - $1 WHERE user_id = $2', [bidData.highestBid, bidData.highestBidder]);
                                await pool.query('INSERT INTO harem (user_id, waifu_id) VALUES ($1, $2) ON CONFLICT DO NOTHING', [bidData.highestBidder, waifu.waifu_id]);

                                bot.sendMessage(groupId, `🎊 <b>Bidding ended!</b>\n\n🏆 Winner: ${bidData.highestBidderName}\n💰 Winning bid: ${bidData.highestBid} 💸 ᴄᴀꜱʜ\n👤 Won: ${waifu.name}!`, { parse_mode: 'HTML' });
                            } else {
                                bot.sendMessage(groupId, `❌ <b>Bidding ended!</b>\n\nWinner didn't have enough 💸 ᴄᴀꜱʜ. ${waifu.name} escaped!`, { parse_mode: 'HTML' });
                            }
                        } else {
                            bot.sendMessage(groupId, `⏰ <b>Bidding ended!</b>\n\nNo bids received. ${waifu.name} escaped!`, { parse_mode: 'HTML' });
                        }

                        await pool.query('UPDATE spawn_tracker SET active_spawn_waifu_id = NULL WHERE group_id = $1', [groupId]);
                        groupBids.delete(groupId);
                    }
                }, 60000);
            }
        }
    }
});

bot.onText(/\/grab/, async (msg) => {
    return sendReply(msg.chat.id, msg.message_id, '❌ /grab has been replaced by the bidding system! Use /bid &lt;amount&gt; during group events.');
});

bot.onText(/\/kill (\d+)/, async (msg, match) => {
    const userId = msg.from.id;

    if (!await hasRole(userId, 'sudo') && !await hasRole(userId, 'dev')) {
        return sendReply(msg.chat.id, msg.message_id, '❌ Sudo permission required!');
    }

    if (!msg.reply_to_message) {
        return sendReply(msg.chat.id, msg.message_id, '❌ Reply to a user!');
    }

    const targetId = msg.reply_to_message.from.id;
    const waifuId = parseInt(match[1]);

    await pool.query('DELETE FROM harem WHERE user_id = $1 AND waifu_id = $2', [targetId, waifuId]);
    sendReply(msg.chat.id, msg.message_id, '✅ Waifu removed from user!');
});

bot.onText(/\/killall (\d+)/, async (msg, match) => {
    const userId = msg.from.id;

    if (!await hasRole(userId, 'sudo') && !await hasRole(userId, 'dev')) {
        return sendReply(msg.chat.id, msg.message_id, '❌ Sudo permission required!');
    }

    const waifuId = parseInt(match[1]);

    await pool.query('DELETE FROM harem WHERE waifu_id = $1', [waifuId]);
    sendReply(msg.chat.id, msg.message_id, '✅ Waifu removed from all users!');
});

bot.onText(/\/give (\d+)/, async (msg, match) => {
    const userId = msg.from.id;

    if (!await hasRole(userId, 'sudo') && !await hasRole(userId, 'dev')) {
        return sendReply(msg.chat.id, msg.message_id, '❌ Sudo permission required!');
    }

    if (!msg.reply_to_message) {
        return sendReply(msg.chat.id, msg.message_id, '❌ Reply to a user!');
    }

    const targetId = msg.reply_to_message.from.id;
    const waifuId = parseInt(match[1]);
    await ensureUser(targetId, msg.reply_to_message.from.username, msg.reply_to_message.from.first_name);

    await pool.query('INSERT INTO harem (user_id, waifu_id) VALUES ($1, $2) ON CONFLICT DO NOTHING', [targetId, waifuId]);
    sendReply(msg.chat.id, msg.message_id, '✅ Waifu given to user!');
});

bot.onText(/\/lock (\d+)/, async (msg, match) => {
    const userId = msg.from.id;

    if (!await hasRole(userId, 'sudo') && !await hasRole(userId, 'dev')) {
        return sendReply(msg.chat.id, msg.message_id, '❌ Sudo permission required!');
    }

    const waifuId = parseInt(match[1]);

    await pool.query('UPDATE waifus SET is_locked = NOT is_locked WHERE waifu_id = $1', [waifuId]);
    sendReply(msg.chat.id, msg.message_id, '✅ Waifu lock toggled!');
});

bot.onText(/\/adduploader(?:@(\w+))?/, async (msg, match) => {
    const userId = msg.from.id;

    if (!await hasRole(userId, 'dev')) {
        return sendReply(msg.chat.id, msg.message_id, '❌ Dev only!');
    }

    let targetId;
    if (msg.reply_to_message) {
        targetId = msg.reply_to_message.from.id;
    } else {
        return sendReply(msg.chat.id, msg.message_id, '❌ Reply to a user!');
    }

    await pool.query('INSERT INTO roles (user_id, role_type, granted_by) VALUES ($1, $2, $3) ON CONFLICT DO NOTHING',
        [targetId, 'uploader', userId]);
    sendReply(msg.chat.id, msg.message_id, '✅ Uploader role granted!');
});

bot.onText(/\/ruploader/, async (msg) => {
    const userId = msg.from.id;

    if (!await hasRole(userId, 'dev')) {
        return sendReply(msg.chat.id, msg.message_id, '❌ Dev only!');
    }

    if (!msg.reply_to_message) {
        return sendReply(msg.chat.id, msg.message_id, '❌ Reply to a user!');
    }

    const targetId = msg.reply_to_message.from.id;

    await pool.query('DELETE FROM roles WHERE user_id = $1 AND role_type = $2', [targetId, 'uploader']);
    sendReply(msg.chat.id, msg.message_id, '✅ Uploader role revoked!');
});

bot.onText(/\/addsudo/, async (msg) => {
    const userId = msg.from.id;

    if (!await hasRole(userId, 'dev')) {
        return sendReply(msg.chat.id, msg.message_id, '❌ Dev only!');
    }

    if (!msg.reply_to_message) {
        return sendReply(msg.chat.id, msg.message_id, '❌ Reply to a user!');
    }

    const targetId = msg.reply_to_message.from.id;

    await pool.query('INSERT INTO roles (user_id, role_type, granted_by) VALUES ($1, $2, $3) ON CONFLICT DO NOTHING',
        [targetId, 'sudo', userId]);
    sendReply(msg.chat.id, msg.message_id, '✅ Sudo role granted!');
});

bot.onText(/\/rsudo/, async (msg) => {
    const userId = msg.from.id;

    if (!await hasRole(userId, 'dev')) {
        return sendReply(msg.chat.id, msg.message_id, '❌ Dev only!');
    }

    if (!msg.reply_to_message) {
        return sendReply(msg.chat.id, msg.message_id, '❌ Reply to a user!');
    }

    const targetId = msg.reply_to_message.from.id;

    await pool.query('DELETE FROM roles WHERE user_id = $1 AND role_type = $2', [targetId, 'sudo']);
    sendReply(msg.chat.id, msg.message_id, '✅ Sudo role revoked!');
});
    const targetId = msg.reply_to_message.from.id;

    await pool.query('INSERT INTO roles (user_id, role_type, granted_by) VALUES ($1, $2, $3) ON CONFLICT DO NOTHING',
        [targetId, 'dev', userId]);
    sendReply(msg.chat.id, msg.message_id, '✅ Dev role granted!');
});

bot.on('callback_query', async (query) => {
    const userId = query.from.id;
    const data = query.data;

    await bot.answerCallbackQuery(query.id);

    if (data === 'menu_credits') {
        const creditsKeyboard = {
            inline_keyboard: [
                [{ text: 'UPLOADERS', callback_data: 'credits_uploaders' }],
                [{ text: 'DEVELOPERS', callback_data: 'credits_developers' }],
                [{ text: 'SUDOS', callback_data: 'credits_sudos' }],
                [{ text: '« Back', callback_data: 'menu_main' }]
            ]
        };

        await bot.editMessageCaption('🏆 <b>CREDITS</b>\n\nSelect a category to view contributors:', {
            chat_id: query.message.chat.id,
            message_id: query.message.message_id,
            reply_markup: creditsKeyboard,
            parse_mode: 'HTML'
        });
    } else if (data === 'credits_uploaders') {
        const uploaders = await pool.query('SELECT DISTINCT u.user_id, u.username, u.first_name FROM roles r JOIN users u ON r.user_id = u.user_id WHERE r.role_type = $1', ['uploader']);

        const uploaderButtons = uploaders.rows.map(u => [{
            text: u.username ? `@${u.username}` : u.first_name,
            url: `tg://user?id=${u.user_id}`
        }]);
        uploaderButtons.push([{ text: '« Back', callback_data: 'menu_credits' }]);

        await bot.editMessageCaption('📤 <b>UPLOADERS</b>\n\nClick to contact:', {
            chat_id: query.message.chat.id,
            message_id: query.message.message_id,
            reply_markup: { inline_keyboard: uploaderButtons },
            parse_mode: 'HTML'
        });
    } else if (data === 'credits_developers') {
        const devs = await pool.query('SELECT DISTINCT u.user_id, u.username, u.first_name FROM roles r JOIN users u ON r.user_id = u.user_id WHERE r.role_type = $1', ['dev']);

        const devButtons = devs.rows.map(u => [{
            text: u.username ? `@${u.username}` : u.first_name,
            url: `tg://user?id=${u.user_id}`
        }]);
        devButtons.push([{ text: '« Back', callback_data: 'menu_credits' }]);

        await bot.editMessageCaption('💻 <b>DEVELOPERS</b>\n\nClick to contact:', {
            chat_id: query.message.chat.id,
            message_id: query.message.message_id,
            reply_markup: { inline_keyboard: devButtons },
            parse_mode: 'HTML'
        });
    } else if (data === 'credits_sudos') {
        const sudos = await pool.query('SELECT DISTINCT u.user_id, u.username, u.first_name FROM roles r JOIN users u ON r.user_id = u.user_id WHERE r.role_type = $1', ['sudo']);

        const sudoButtons = sudos.rows.map(u => [{
            text: u.username ? `@${u.username}` : u.first_name,
            url: `tg://user?id=${u.user_id}`
        }]);
        sudoButtons.push([{ text: '« Back', callback_data: 'menu_credits' }]);

        await bot.editMessageCaption('🛡️ <b>SUDOS</b>\n\nClick to contact:', {
            chat_id: query.message.chat.id,
            message_id: query.message.message_id,
            reply_markup: { inline_keyboard: sudoButtons },
            parse_mode: 'HTML'
        });
    } else if (data === 'menu_help') {
        const helpKeyboard = {
            inline_keyboard: [
                [{ text: '« Back', callback_data: 'menu_main' }]
            ]
        };

        await bot.editMessageCaption('💬 <b>HELP CONTACTS</b>\n\n@SHUBHXM_FR | ID: 8195158525\n@THEGAMERADEPT | ID: 6245574035\n\nClick to contact:', {
            chat_id: query.message.chat.id,
            message_id: query.message.message_id,
            reply_markup: helpKeyboard,
            parse_mode: 'HTML'
        });
    } else if (data === 'menu_main') {
        const mainMenuKeyboard = {
            inline_keyboard: [
                [{ text: 'ADD ME BABY 💖', url: `https://t.me/${bot.options.username}?startgroup=true` }],
                [{ text: 'CREDITS', callback_data: 'menu_credits' }],
                [{ text: 'HELP', callback_data: 'menu_help' }],
                [{ text: 'UPDATES', url: 'https://t.me/+_oaZBApwiFsyNzU1' }]
            ]
        };

        await bot.editMessageCaption('👋 ʜɪ, ᴍʏ ɴᴀᴍᴇ ɪs 𝗔𝗾𝘂𝗮 𝗪𝗮𝗶𝗳𝘂 𝗯𝗼𝘁, ᴀɴ ᴀɴɪᴍᴇ-ʙᴀsᴇᴅ ɢᴀᴍᴇs ʙᴏᴛ! ᴀᴅᴅ ᴍᴇ ᴛᴏ ʏᴏᴜʀ ɢʀᴏᴜᴘ ᴀɴᴅ ᴛʜᴇ ᴇxᴘᴇʀɪᴇɴᴄᴇ ɢᴇᴛs ᴇxᴘᴀɴᴅᴇᴅ. ʟᴇᴛ's ɪɴɪᴛɪᴀᴛᴇ ᴏᴜʀ ᴊᴏᴜʀɴᴇʏ ᴛᴏɢᴇᴛʜᴇʀ!', {
            chat_id: query.message.chat.id,
            message_id: query.message.message_id,
            reply_markup: mainMenuKeyboard,
            parse_mode: 'HTML'
        });
    } else if (data.startsWith('filter_')) {
        let rarityCondition = '';
        let filterName = 'All Waifus';

        if (data === 'filter_all') {
            rarityCondition = '';
            filterName = 'All Waifus';
        } else if (data.startsWith('filter_rarity_')) {
            const rarityPart = data.replace('filter_rarity_', '');
            if (rarityPart.includes('-')) {
                const [min, max] = rarityPart.split('-');
                rarityCondition = `AND w.rarity BETWEEN ${min} AND ${max}`;
                filterName = RARITY_NAMES[parseInt(min)];
            } else {
                rarityCondition = `AND w.rarity = ${rarityPart}`;
                filterName = RARITY_NAMES[parseInt(rarityPart)];
            }
        }

        const queryText = `
            SELECT w.*, h.acquired_date 
            FROM harem h 
            JOIN waifus w ON h.waifu_id = w.waifu_id 
            WHERE h.user_id = $1 ${rarityCondition}
            ORDER BY h.acquired_date DESC 
            LIMIT 20
        `;

        const result = await pool.query(queryText, [userId]);

        if (result.rows.length === 0) {
            return bot.sendMessage(query.message.chat.id, `📭 No waifus found for filter: ${filterName}`);
        }

        let message = `📚 <b>${filterName} Waifus (${result.rows.length}):</b>\n\n`;

        result.rows.forEach((w, i) => {
            message += `${i + 1}. ${w.name} - ${w.anime} [${RARITY_NAMES[w.rarity]}] (ID: ${w.waifu_id})\n`;
        });

        bot.sendMessage(query.message.chat.id, message, { parse_mode: 'HTML' });
    } else if (data.startsWith('top_')) {
        if (data === 'top_cash') {
            const cashTop = await pool.query('SELECT user_id, username, first_name, berries FROM users ORDER BY berries DESC LIMIT 10');

            let message = '💸 <b>TOP 💸 ᴄᴀꜱʜ HOLDERS</b>\n\n';
            cashTop.rows.forEach((u, i) => {
                const name = u.username ? `@${u.username}` : u.first_name;
                message += `${i + 1}. ${name} - ${u.berries} 💸 ᴄᴀꜱʜ\n`;
            });

            const topKeyboard = {
                inline_keyboard: [
                    [
                        { text: '💸 ᴄᴀꜱʜ', callback_data: 'top_cash' },
                        { text: '🩷 ᴡᴀɪғᴜs', callback_data: 'top_waifus' }
                    ]
                ]
            };

            await bot.editMessageText(message, {
                chat_id: query.message.chat.id,
                message_id: query.message.message_id,
                reply_markup: topKeyboard,
                parse_mode: 'HTML'
            });
        } else if (data === 'top_waifus') {
            const waifuTop = await pool.query(
                'SELECT u.user_id, u.username, u.first_name, COUNT(h.waifu_id) as count FROM users u JOIN harem h ON u.user_id = h.user_id GROUP BY u.user_id ORDER BY count DESC LIMIT 10'
            );

            let message = '🩷 <b>TOP WAIFU COLLECTORS</b>\n\n';
            waifuTop.rows.forEach((u, i) => {
                const name = u.username ? `@${u.username}` : u.first_name;
                message += `${i + 1}. ${name} - ${u.count} waifus\n`;
            });

            const topKeyboard = {
                inline_keyboard: [
                    [
                        { text: '💸 ᴄᴀꜱʜ', callback_data: 'top_cash' },
                        { text: '🩷 ᴡᴀɪғᴜs', callback_data: 'top_waifus' }
                    ]
                ]
            };

            await bot.editMessageText(message, {
                chat_id: query.message.chat.id,
                message_id: query.message.message_id,
                reply_markup: topKeyboard,
                parse_mode: 'HTML'
            });
        }
    }
});

pool.query(`
    CREATE TABLE IF NOT EXISTS bot_settings (
        key VARCHAR(100) PRIMARY KEY,
        value TEXT
    )
`).catch(err => console.error('Error creating bot_settings table:', err));

pool.query(`
    ALTER TABLE banned_users ADD COLUMN IF NOT EXISTS stored_berries BIGINT DEFAULT 0,
    ADD COLUMN IF NOT EXISTS stored_waifus TEXT
`).catch(err => console.error('Error updating banned_users table:', err));

pool.query(`
    ALTER TABLE waifus ADD COLUMN IF NOT EXISTS gender VARCHAR(20) DEFAULT 'Female',
    ADD COLUMN IF NOT EXISTS price BIGINT DEFAULT 0
`).catch(err => console.error('Error updating waifus table:', err));

console.log('✅ Waifu Bot is running!');